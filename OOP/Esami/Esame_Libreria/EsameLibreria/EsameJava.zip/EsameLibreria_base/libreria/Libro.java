package libreria;

public class Libro {

    private String titolo;
	private String autore;
	private int anno;
	private double prezzo;
	private Editore editore;
	private int quantita;
	private int[] settimane = new int[53];
	private int[] mesi = new int[13];
	private Libreria lib;
	private int quantitaRiordino;
	private int soglia;


	public Libro(String titolo, String autore, int anno, double prezzo,
			Editore editore,Libreria libreria) {
		this.titolo=titolo;
		this.autore=autore;
		this.anno=anno;
		this.prezzo=prezzo;
		this.editore=editore;
		this.lib=libreria;
	}

	public String getTitolo(){
        return this.titolo;
    }
    
    public String getAutore(){
        return this.autore;
    }
    
    public int getAnno(){
        return this.anno;
    }

    public double getPrezzo(){
        return this.prezzo;
    }
    
    public Editore getEditore(){
        return this.editore;
    }

    public void setQuantita(int q){
    	this.quantita=q;
    }
    
    public int getQuantita(){
        return this.quantita;	
    }

    public void registraVendita(int settimana, int mese){
    	if(settimana>0 && settimana<=52 && mese>0 && mese<=12){
    	settimane[settimana]++;
    	mesi[mese]++;
    	this.quantita--;
    	if(this.quantita==this.soglia){
    		this.lib.setOrdine(this.editore,this,this.quantitaRiordino);
    	}
    	}
    }
    
    public int getSettimana(int settimana){
    	if(settimana>0 && settimana<52){
    	return settimane[settimana];
    	}
    	
    	return -1;
    }
    
    public int getMese(int mese){
    	if(mese>1 && mese<12){
    	return mesi[mese];
    	}
    	return -1;
    }
    

    public void setParametri(int soglia, int quantitaRiordino){  
    	this.soglia=soglia;
    	this.quantitaRiordino=quantitaRiordino;
    }
    
    
    
    @Override
    public String toString(){
    	return this.titolo + " - " +  this.autore + " - " + this.anno + " " + this.editore.getNome();
    	
    }
}
