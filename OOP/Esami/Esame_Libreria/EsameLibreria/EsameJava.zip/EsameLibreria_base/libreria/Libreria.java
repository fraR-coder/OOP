package libreria;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.*;


public class Libreria {
	// STRUTTURA DATI
	private Map<String,Editore> editori = new TreeMap<>(); // TreeMap per tenere ordinati gli editori per ordine alfabetico
	private List<Libro> libri = new LinkedList<>();
	private List<Ordine> ordini = new ArrayList<>();
	private int numeroOrdini=0;

    public Editore creaEditore(String nome, int tempoConsegna, String email){
        if(editori.containsKey(nome)){
        	return editori.get(nome);        	
        }
    	Editore e = new Editore(nome,tempoConsegna,email);
    	editori.put(nome,e);
        return e;
    }

    public Editore getEditore(String nome){
    	
        return editori.get(nome);
    }

    public Collection getEditori(){
        return editori.values();
    }
    
    public Collection getLibri(){
        return this.libri;
    }

    public Libro creaLibro(String titolo, String autore, int anno, double prezzo, String nomeEditore)
    			throws EditoreInesistente {
    	if(!editori.containsKey(nomeEditore)){
    		throw new EditoreInesistente();
    	}
    	
    	Libro l = new Libro(titolo,autore,anno,prezzo,editori.get(nomeEditore),this);
    	libri.add(l);
        return l;
    }
    
    public Libro getLibro(String autore, String titolo){
        if(autore==null){
        	for(Libro l:libri){ if(l.getTitolo().equals(titolo)){return l;}}
        }else if(titolo==null){
        	for(Libro l:libri){ if(l.getAutore().equals(autore)){return l;}}

    }
        for(Libro l:libri){ if((l.getAutore().equals(autore)) && (l.getTitolo().equals(titolo))){return l;}}
        return null;
    }
    
    public Collection getClassificaSettimana(final int settimana){
    	List<Libro> array = new LinkedList<>(libri);
    	Collections.sort(array,(a,b)-> Integer.compare(b.getSettimana(settimana),a.getSettimana(settimana)));
    	return array;
    	
    	
   // 	return libri.stream().sorted((s,w) -> (w.getSettimana(settimana) - s.getSettimana(settimana) )).collect(Collectors.toList());
    	
        // return libri.stream().sorted(Comparator.comparing(s -> ((Libro) s).getSettimana(settimana))).collect(Collectors.toList());
    }
    
    public Collection getClassificaMese(final int mese){
   	 return libri.stream().sorted((s,w) -> (w.getMese(mese) - s.getMese(mese) )).collect(Collectors.toList());
    }
    
    public Collection getOrdini(){
        return this.ordini;
    }
    
    public void ordineRicevuto(int numOrdine){
    	System.out.println("!!!"+this.ordini.get(numOrdine));
    	this.ordini.get(numOrdine).Consegnato();
    	this.ordini.get(numOrdine).getLibro().setQuantita(this.ordini.get(numOrdine).getLibro().getQuantita() + this.ordini.get(numOrdine).getQuantita());
    }
    
    public void leggi(String file) throws NumberFormatException, EditoreInesistente, IOException{
		Reader r = new FileReader(file);
		BufferedReader b = new BufferedReader (r);
		String s;
		while((s=b.readLine()) != null){
			try{
			String parole[]= s.split(";");
			if(parole[0].equals("E") && parole.length==4){
				creaEditore(parole[1],Integer.parseInt(parole[2].trim()),parole[3]);
			}else{
				if(parole[0].equals("L") && parole.length==7){
					Libro l = creaLibro(parole[1],parole[2],Integer.parseInt(parole[3].trim()),Double.parseDouble(parole[4].trim()),parole[5]);
					l.setQuantita(Integer.parseInt(parole[6].trim()));
				}
			}
			
			
		}catch(NumberFormatException nfe){
			continue;
		}
		}
		b.close();
		r.close();	
    }
    
    
    
	public void setOrdine(Editore editore, Libro libro, int quantita) {
	Ordine o= new Ordine(editore,libro,quantita,numeroOrdini);
	ordini.add(o);  // add(numeroOrdini,o) cosa cambia?
	numeroOrdini++;
	
	}

}
