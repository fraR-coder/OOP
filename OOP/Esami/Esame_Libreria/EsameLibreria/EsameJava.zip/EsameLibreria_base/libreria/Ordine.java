package libreria;

public class Ordine {
	
    private Editore editore;
	private Libro libro;
	private int quantita;
	private int numero;
	private boolean consegnato;

	public Ordine(Editore editore, Libro libro, int quantita, int numeroOrdini) {
	this.editore=editore;
	this.libro=libro;
	this.quantita=quantita;
	this.numero=numeroOrdini;
	this.consegnato=false;
    }

	public Editore getEditore(){
        return editore;
    }
    
    public Libro getLibro(){
        return libro;
    }
    
    public int getQuantita(){
        return quantita;
    }

    public boolean isConsegnato(){
        return consegnato;
    }
    
    public void Consegnato(){
    	this.consegnato=true;
    }
    

    public int getNumero(){
        return numero;
    }
    
    @Override
    public String toString(){
    return "("+this.numero+") " + this.libro.getTitolo() + " " + this.quantita;	
    }
}
