package libreria;

public class EditoreInesistente extends Exception {

}
