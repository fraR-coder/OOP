package grocerystore;

public class Product implements Comparable<Product>{
	String code;
	String name;
	double price;
	
	public Product(String c, String n, double p){
		code=c;
		name=n;
		price=p;
	}
	
	public String getName(){
		return name;
	} 
	
	public double getPrice(){
		return price;
	
	}

	@Override
	public int compareTo(Product o) {
		return name.compareTo(o.getName());
	}
}
