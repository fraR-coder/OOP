package grocerystore;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class GroceryCounter implements Counter {
	Map<String,Product> inventory = new HashMap<String,Product>();
	Map<Product,Integer> shopping = new TreeMap<Product,Integer>();
	double total = 0.0;
	Product discProd;
	double discPrice;

	public void addProduct(String code, String desc, double price) {
		Product p = new Product(code, desc, price);
		inventory.put(code, p);
	}

	public void promo(String code, int discount) {
		Product p = inventory.get(code);
		if(p==null)
			discProd = null;
		else {
			discProd = p;
			discPrice = p.getPrice()*(1-discount/100.);
		}
	}

	public void read(String code, int pieces) throws NoSuchProduct{
		Product p = inventory.get(code);
		if(p==null)
			throw(new NoSuchProduct(code));
		Integer previous = shopping.get(p);
		previous = previous==null ? 0 : previous;
		shopping.put(p, pieces+previous);
		double price = p==discProd ? discPrice : p.getPrice();
		total += pieces * price;
	}
	
	public double total() {
		return total;
	}

	public double gross() {
		return total + taxes();
	}

	public double taxes() {
		return total * VAT;
	}
/*
	public String invoice() {
		Set<Product> s = shopping.keySet();
		String inv = "";
		for(Product p : s){
			int n = shopping.get(p);
			double price = p==discProd ? discPrice : p.getPrice();
			inv += n+" x "+p.getName()+" \t> "+n*price+"\n";
		}
		inv += "\nTotal: \t> "+total+"\n"
		 	+ "VAT: \t> "+taxes()+"\n"
			+ "Gross: \t> "+gross()+"\n";
		return inv;
	}
*/	
	public String invoice() {
		StringBuffer inv = new StringBuffer();
		shopping.keySet()
			.stream()
			.forEach(p -> { int n = shopping.get(p);
							double price = p==discProd ? discPrice : p.getPrice();
							inv.append(n+" x "+p.getName()+" \t> "+n*price+"\n");
			})
		;
		inv.append("\nTotal: \t> "+total+"\n"
					+"VAT: \t> "+taxes()+"\n"
					+"Gross: \t> "+gross()+"\n");
		return inv.toString();
	}
	
	public void print() {

		System.out.println(invoice());
	}
	
	public void close() {
		shopping.clear();
		total=0.0;
	}
}
