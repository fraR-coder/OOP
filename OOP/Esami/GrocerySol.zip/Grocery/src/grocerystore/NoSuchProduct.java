package grocerystore;

public class NoSuchProduct extends Exception {
	String code;
	public NoSuchProduct(String c){
		code=c;
	}
	public String getMessage(){
		return "Unexisting code "+code;
	}

}
