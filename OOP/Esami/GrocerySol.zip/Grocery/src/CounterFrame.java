import grocerystore.GroceryCounter;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class CounterFrame extends JFrame {
	static GroceryCounter counter;
	JTextField code, num;
	JButton read, print, reset;
	JTextArea invoice;
	
  public CounterFrame(String title){
	  super(title);
	  Container container = getContentPane();
	  container.setLayout( new FlowLayout() );
	  JLabel product = new JLabel("product code:");
	  container.add( product );
	  code = new JTextField( "P001",4 );
	  container.add( code );
	  JLabel number = new JLabel("number of pieces:");
	  container.add( number );
	  num = new JTextField("2", 3 );
	  container.add( num );
	  read = new JButton("Read");
	  container.add( read );
	  print = new JButton("Print Invoice");
	  container.add( print );
	  reset = new JButton("Reset Counter");
	  container.add( reset );
	  invoice = new JTextArea("*****************************\n 2 x Coffee	> 6.0\n 1 x Olive oil	> 2.0\n 3 x Tuna	> 4.5\n\nTotal:	> 12.5\nVAT 20%	> 2.5\n\nGrossTotal	> 15.0\n*****************************\n	", 10,25);
	  container.add( new JScrollPane(invoice) );    
	  setDefaultCloseOperation(DISPOSE_ON_CLOSE);	    
	  setSize(400, 300);
	  setResizable(false);
	  setVisible(true);
	  ButtonHandler rh = new ButtonHandler();
	  read.addActionListener(rh);
	  print.addActionListener(rh);
	  reset.addActionListener(rh);
	  invoice.setText("");
  }
  private class ButtonHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			if(event.getSource()== read){
				String c = code.getText();
				int n = Integer.parseInt(num.getText());
				try	{	
					counter.read(c, n);	
				}
				catch(Exception ex){
					invoice.setText(ex.getMessage());
				}
			}
			if(event.getSource()== print){
				invoice.setText(counter.invoice());
			}
			if(event.getSource()== reset){
				invoice.setText("");
				counter.close();
			}
		}
	}
	 
  public static void main(String[] args) {
	new CounterFrame("Counter Check out");
	counter = new GroceryCounter();
	
	counter.addProduct("P001", "Coffee", 3.0);
	counter.addProduct("P002", "Tuna", 2.4);
	counter.addProduct("P003", "Oil", 2.0);
	
	counter.promo("P002", 20); // 20% discount on tuna
  }
}
